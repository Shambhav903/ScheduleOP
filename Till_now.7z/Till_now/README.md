# ScheduleOP
Project on Schedule Optimization using Genetic Algorithm. <br> CM 5th semester.
<br>
The Team: <br> Aayam Basyal <br> Aayush Shrestha <br> Ankur Baral <br> Ruby Shrestha <br> Shambhav Rayamajhi
