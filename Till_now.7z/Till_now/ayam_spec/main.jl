include("rewardFunc.jl")
include("GA.jl")
using .reward
using Random
using TypedTables

random = "Gb2Ba1Cc3Fa1Gb3Gc2Gc1Ba3Gb2Bb3Dc2Ea1Fb2Ga3Bc1Aa2Ec3Fb1Cb1Cc2Ga3Db3Ec2Da1Ca2Ac1Db3Gb2Fa3Dc1Eb1Ca3Cc2Cc2Aa1Ab3Ea1Cc2Bb3Da3Ac1Ab2Gb1Ga2Fc3Ga2Cb3Fc1Gb2Ga3Cc1Bc3Ga2Eb1"
random2 = "Ba1Eb3Bc2Ba1Gb3Ec2Gc3Aa1Gb2Gb3Fa1Gc2Gb2Fa3Gc1Cb3Gc1Ea2Aa2Dc1Fb3Ac3Eb2Da1Ea2Ec1Db3Bb3Gc2Aa1Bb1Ca3Ac2Fc3Aa2Ab1Aa1Cc2Cb3Ab3Gc1Aa2Fb1Ga3Fc2Ga2Dc3Gb1Gb2Ca3Cc1Bc3Da1Db2"
random3 = "Ab2Ba1Dc3Ga1Gb3Ec2Gc1Ga2Gb3Bb3Dc2Ea1Ab1Ga3Ac2Gb1Fc3Da2Fa3Bb2Bc1Cb3Gc2Ba1Ga2Cc3Eb1Gb1Ga3Ac2Fb1Ca3Cc2Ec2Fa1Db3Ea1Cc2Gb3Aa3Cc1Cb2Fb1Ga2Bc3Aa2Eb3Fc1Gb2Ca3Cc1Gc1Da3Db2"
random4 = "Aa1Ac3Eb2Ga2Gb2Aa3Gc1Ec1Da1Ba1Ga1Ac1Cb3Ab2Ec1Ba3Ec1Fc3Fc1Fb2Gb1Bb1Gb1Ac2Bb3Fb3Ab3Fc3Gb2Fb2Aa3Db1Ea3Aa3Eb1Da3Dc2Db1Fa1Db2Da3Ea2Db1Ca1Db2Aa3Fb1Ba1Dc2Fb3Dc2Ab3Gb1Ea1"

println(reward.get_reward(random4,test = true))

a,b = run_my_algo()

println(b[1])

display2(random2)

println(reward.get_reward(b[1],test = true))